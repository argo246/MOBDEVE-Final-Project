package com.mobdeve.s19.group2.mco2.model

class CourtName(imageId: Int, courtName: String,  address: String, businessHours: String, mapResId: Int) {
    var imageId = imageId
        private set

    var courtName = courtName
        private set

    var address = address
        private set

    var businessHours = businessHours
        private set

    var mapResId = mapResId
        private set

}

